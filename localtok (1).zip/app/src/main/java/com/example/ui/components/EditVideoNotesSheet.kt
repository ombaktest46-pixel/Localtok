package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VideoItem
import com.example.ui.theme.TikTokBlack
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokDarkSurface
import com.example.ui.theme.TikTokSurfaceVariant
import com.example.ui.theme.TikTokTextSecondary
import com.example.ui.theme.TikTokWhite
import com.example.ui.theme.TikTokYellow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditVideoNotesSheet(
    video: VideoItem,
    onDismiss: () -> Unit,
    onSaveNotes: (soundTitle: String, caption: String, authorHandle: String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var soundTitleInput by remember(video.id) { mutableStateOf(video.soundTitle) }
    var captionInput by remember(video.id) { mutableStateOf(video.caption) }
    var authorHandleInput by remember(video.id) { mutableStateOf(video.authorHandle) }

    val quickTags = listOf(
        "#catatanlagu",
        "#lagufavorit",
        "#chordgitar",
        "#slowed",
        "#akustik",
        "#lirik",
        "#chill",
        "#fyp"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = TikTokBlack,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(40.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.25f))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .padding(bottom = 36.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(TikTokYellow.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = null,
                            tint = TikTokYellow,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Catatan Lagu & Video",
                            color = TikTokWhite,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Kustomisasi nama lagu & tagar video ini",
                            color = TikTokTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Tutup",
                        tint = TikTokTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Current File pill
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(TikTokDarkSurface)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "File: ${video.fileName}",
                    color = TikTokTextSecondary,
                    fontSize = 11.5.sp,
                    maxLines = 1
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Field 1: Judul Lagu / Sound Title
            Text(
                text = "Judul Musik / Catatan Lagu 🎵",
                color = TikTokWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = soundTitleInput,
                onValueChange = { soundTitleInput = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("edit_sound_title_input"),
                placeholder = { Text("Contoh: DJ Viral / Sheila On 7 - Dan") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = TikTokCyan
                    )
                },
                trailingIcon = {
                    if (soundTitleInput.isNotEmpty()) {
                        IconButton(onClick = { soundTitleInput = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TikTokTextSecondary)
                        }
                    }
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TikTokWhite,
                    unfocusedTextColor = TikTokWhite,
                    focusedContainerColor = TikTokSurfaceVariant,
                    unfocusedContainerColor = TikTokDarkSurface,
                    focusedBorderColor = TikTokCyan,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.15f)
                ),
                shape = RoundedCornerShape(10.dp)
            )
            Text(
                text = "Nama lagu ini akan tampil di samping ikon musik 🎵 dan piringan kaset.",
                color = TikTokTextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 4.dp, top = 2.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Field 2: Caption & Hashtags
            Text(
                text = "Deskripsi, Catatan & Tagar 📝",
                color = TikTokWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = captionInput,
                onValueChange = { captionInput = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("edit_caption_input"),
                placeholder = { Text("Tulis catatanmu, chord, atau tagar...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.EditNote,
                        contentDescription = null,
                        tint = TikTokYellow
                    )
                },
                minLines = 2,
                maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TikTokWhite,
                    unfocusedTextColor = TikTokWhite,
                    focusedContainerColor = TikTokSurfaceVariant,
                    unfocusedContainerColor = TikTokDarkSurface,
                    focusedBorderColor = TikTokYellow,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.15f)
                ),
                shape = RoundedCornerShape(10.dp)
            )

            // Quick Tag Chips
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Pintasan Tagar Cepat (Sentuh untuk menambahkan):",
                color = TikTokTextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                quickTags.take(4).forEach { tag ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (captionInput.contains(tag)) TikTokYellow.copy(alpha = 0.25f) else TikTokDarkSurface)
                            .clickable {
                                if (!captionInput.contains(tag)) {
                                    captionInput = if (captionInput.isBlank()) tag else "$captionInput $tag"
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = tag,
                            color = if (captionInput.contains(tag)) TikTokYellow else TikTokTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                quickTags.drop(4).forEach { tag ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (captionInput.contains(tag)) TikTokYellow.copy(alpha = 0.25f) else TikTokDarkSurface)
                            .clickable {
                                if (!captionInput.contains(tag)) {
                                    captionInput = if (captionInput.isBlank()) tag else "$captionInput $tag"
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = tag,
                            color = if (captionInput.contains(tag)) TikTokYellow else TikTokTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Field 3: Creator Handle
            Text(
                text = "Nama Akun / Kreator 👤",
                color = TikTokWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = authorHandleInput,
                onValueChange = { authorHandleInput = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("edit_author_input"),
                placeholder = { Text("Contoh: @yogreks atau @penyanyi") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = TikTokTextSecondary
                    )
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TikTokWhite,
                    unfocusedTextColor = TikTokWhite,
                    focusedContainerColor = TikTokSurfaceVariant,
                    unfocusedContainerColor = TikTokDarkSurface,
                    focusedBorderColor = TikTokWhite,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.15f)
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        val sound = if (soundTitleInput.isNotBlank()) soundTitleInput else video.soundTitle
                        val caption = if (captionInput.isNotBlank()) captionInput else video.caption
                        val author = if (authorHandleInput.isNotBlank()) authorHandleInput else video.authorHandle
                        onSaveNotes(sound, caption, author)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TikTokYellow),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("save_notes_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Save,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Simpan Catatan",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TikTokWhite),
                    modifier = Modifier.height(48.dp)
                ) {
                    Text(text = "Batal", color = TikTokWhite)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            TextButton(
                onClick = {
                    val cleanFile = video.fileName.substringBeforeLast('.').replace('_', ' ')
                    soundTitleInput = "Original Sound - $cleanFile"
                    captionInput = "$cleanFile #fyp #catatanlagu"
                    authorHandleInput = "@offline_creator"
                },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text(
                    text = "Kembalikan ke Nama File Asli",
                    color = TikTokTextSecondary,
                    fontSize = 12.sp
                )
            }
        }
    }
}
