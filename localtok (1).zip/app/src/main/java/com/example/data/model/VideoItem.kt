package com.example.data.model

import android.net.Uri

data class VideoItem(
    val id: String,
    val uri: Uri,
    val filePath: String,
    val fileName: String,
    val title: String,
    val authorName: String,
    val authorHandle: String,
    val caption: String,
    val soundTitle: String,
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L,
    val isLiked: Boolean = false,
    val likeCount: Int = 0,
    val isBookmarked: Boolean = false,
    val bookmarkCount: Int = 0,
    val commentCount: Int = 0,
    val shareCount: Int = 0,
    val isLooping: Boolean = true,
    val isSample: Boolean = false,
    val comments: List<CommentItem> = emptyList()
)
