package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokRed
import com.example.ui.theme.TikTokTextSecondary
import com.example.ui.theme.TikTokWhite

@Composable
fun TikTokBottomNavBar(
    selectedTab: String,
    onTabSelected: (String) -> Unit,
    onAddClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            // 1. Beranda
            NavItem(
                icon = Icons.Default.Home,
                label = "Beranda",
                isSelected = selectedTab == "Beranda",
                onClick = { onTabSelected("Beranda") }
            )

            // 2. Toko (with red notification dot)
            NavItem(
                icon = Icons.Default.ShoppingBag,
                label = "Toko",
                isSelected = selectedTab == "Toko",
                hasRedDot = true,
                onClick = { onTabSelected("Toko") }
            )

            // 3. Iconic TikTok '+' Button
            TikTokPlusButton(onClick = onAddClick)

            // 4. Kotak Masuk (with '40' badge)
            NavItem(
                icon = Icons.Outlined.ChatBubbleOutline,
                label = "Kotak Masuk",
                isSelected = selectedTab == "Kotak Masuk",
                badgeText = "40",
                onClick = { onTabSelected("Kotak Masuk") }
            )

            // 5. Profil
            NavItem(
                icon = Icons.Default.PersonOutline,
                label = "Profil",
                isSelected = selectedTab == "Profil",
                onClick = { onTabSelected("Profil") }
            )
        }
    }
}

@Composable
private fun NavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    hasRedDot: Boolean = false,
    badgeText: String? = null,
    onClick: () -> Unit
) {
    val color = if (isSelected) TikTokWhite else TikTokTextSecondary
    Column(
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(24.dp)
            )

            // Red dot indicator
            if (hasRedDot) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .offset(x = 2.dp, y = (-1).dp)
                        .clip(CircleShape)
                        .background(TikTokRed)
                )
            }

            // Numeric badge e.g. "40"
            if (badgeText != null) {
                Box(
                    modifier = Modifier
                        .offset(x = 10.dp, y = (-4).dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(TikTokRed)
                        .padding(horizontal = 4.dp, vertical = 0.5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = badgeText,
                        color = TikTokWhite,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Text(
            text = label,
            color = color,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
fun TikTokPlusButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .width(46.dp)
            .height(30.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        // Left Cyan highlight
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .width(40.dp)
                .height(28.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(TikTokCyan)
        )

        // Right Red highlight
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(40.dp)
                .height(28.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(TikTokRed)
        )

        // Center White pill
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .width(38.dp)
                .height(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(TikTokWhite),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Tambah Video",
                tint = Color.Black,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
