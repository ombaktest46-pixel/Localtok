package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.ui.AspectRatioFrameLayout
import com.example.data.model.CommentItem
import com.example.data.model.VideoItem
import com.example.data.repository.VideoRepository
import com.example.util.SampleVideoGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class FlyingHeart(
    val id: Long,
    val x: Float,
    val y: Float,
    val rotation: Float
)

data class TikTokUiState(
    val videos: List<VideoItem> = emptyList(),
    val currentIndex: Int = 0,
    val isPlaying: Boolean = true,
    val isMuted: Boolean = false,
    val isLoopEnabled: Boolean = true,
    val resizeMode: Int = AspectRatioFrameLayout.RESIZE_MODE_FIT,
    val isClearDisplay: Boolean = false,
    val selectedTab: String = "Saran",
    val selectedNav: String = "Beranda",
    val isLoading: Boolean = false,
    val targetDirectory: String = VideoRepository.DEFAULT_FOLDER_PATH,
    val hasStoragePermission: Boolean = false,
    val showFolderManager: Boolean = false,
    val showCommentsSheet: Boolean = false,
    val showInfoSheet: Boolean = false,
    val showMusicSheet: Boolean = false,
    val showEditNotesSheet: Boolean = false,
    val videoToEdit: VideoItem? = null,
    val savedMusics: Set<String> = setOf("Hymn for the Weekend - Coldplay", "DJ TikTok Slow Viral 2026"),
    val flyingHearts: List<FlyingHeart> = emptyList(),
    val feedbackMessage: String? = null
) {
    val currentVideo: VideoItem?
        get() = videos.getOrNull(currentIndex)
}

class TikTokViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = VideoRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(
        TikTokUiState(targetDirectory = repository.getSavedDirectoryPath())
    )
    val uiState: StateFlow<TikTokUiState> = _uiState.asStateFlow()

    init {
        loadVideos(repository.getSavedDirectoryPath())
    }

    fun loadVideos(customPath: String? = null) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val rawPath = customPath ?: _uiState.value.targetDirectory
            val path = VideoRepository.sanitizePath(rawPath)
            repository.saveDirectoryPath(path)
            val loadedVideos = repository.loadAndShuffleVideos(path)
            _uiState.update {
                it.copy(
                    videos = loadedVideos,
                    currentIndex = 0,
                    isPlaying = true,
                    isLoading = false,
                    targetDirectory = path
                )
            }
        }
    }

    /**
     * Reshuffle offline FYP algorithm
     */
    fun shuffleFyp() {
        val current = _uiState.value.videos
        if (current.isNotEmpty()) {
            val reshuffled = repository.shuffleFyp(current)
            _uiState.update {
                it.copy(
                    videos = reshuffled,
                    currentIndex = 0,
                    isPlaying = true,
                    feedbackMessage = "Offline FYP Re-shuffled!"
                )
            }
        }
    }

    fun onPageChanged(index: Int) {
        if (index in 0 until _uiState.value.videos.size) {
            _uiState.update {
                it.copy(
                    currentIndex = index,
                    isPlaying = true
                )
            }
        }
    }

    fun togglePlayPause() {
        _uiState.update { it.copy(isPlaying = !it.isPlaying) }
    }

    fun toggleMute() {
        _uiState.update {
            val newMuted = !it.isMuted
            it.copy(
                isMuted = newMuted,
                feedbackMessage = if (newMuted) "Audio Muted 🔇" else "Audio Unmuted 🔊"
            )
        }
    }

    fun toggleLoop() {
        _uiState.update {
            val newLoop = !it.isLoopEnabled
            it.copy(
                isLoopEnabled = newLoop,
                feedbackMessage = if (newLoop) "Loop Mode: Repeat Video 🔁" else "Loop Mode: Auto-scroll to Next ⏭️"
            )
        }
    }

    fun toggleResizeMode() {
        _uiState.update { state ->
            val newMode = if (state.resizeMode == AspectRatioFrameLayout.RESIZE_MODE_FIT) {
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            } else {
                AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
            state.copy(
                resizeMode = newMode,
                feedbackMessage = if (newMode == AspectRatioFrameLayout.RESIZE_MODE_FIT) {
                    "Mode Rasio: 4:3 Fit (Asli)"
                } else {
                    "Mode Rasio: Penuh Layar (Zoom)"
                }
            )
        }
    }

    fun toggleClearDisplay() {
        _uiState.update { state ->
            val next = !state.isClearDisplay
            state.copy(
                isClearDisplay = next,
                feedbackMessage = if (next) "Layar Bersih Aktif (Ketuk untuk kembalikan)" else null
            )
        }
    }

    fun setClearDisplay(clear: Boolean) {
        _uiState.update { it.copy(isClearDisplay = clear) }
    }

    fun setSelectedTab(tab: String) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun setSelectedNav(nav: String) {
        _uiState.update { it.copy(selectedNav = nav) }
    }

    fun toggleBookmark(videoId: String) {
        _uiState.update { state ->
            val updated = state.videos.map { v ->
                if (v.id == videoId) {
                    val nextBookmark = !v.isBookmarked
                    v.copy(
                        isBookmarked = nextBookmark,
                        bookmarkCount = if (nextBookmark) v.bookmarkCount + 1 else (v.bookmarkCount - 1).coerceAtLeast(0)
                    )
                } else v
            }
            val isNowBookmarked = updated.firstOrNull { it.id == videoId }?.isBookmarked == true
            state.copy(
                videos = updated,
                feedbackMessage = if (isNowBookmarked) "Disimpan ke Favorit ⭐️" else "Dihapus dari Favorit"
            )
        }
    }

    fun toggleLike(videoId: String) {
        _uiState.update { state ->
            val updated = state.videos.map { v ->
                if (v.id == videoId) {
                    val nextLiked = !v.isLiked
                    repository.toggleLike(videoId, v.isLiked)
                    v.copy(
                        isLiked = nextLiked,
                        likeCount = if (nextLiked) v.likeCount + 1 else (v.likeCount - 1).coerceAtLeast(0)
                    )
                } else v
            }
            state.copy(videos = updated)
        }
    }

    fun onDoubleTapLike(videoId: String, x: Float, y: Float) {
        // Ensure video is liked
        _uiState.update { state ->
            val updated = state.videos.map { v ->
                if (v.id == videoId && !v.isLiked) {
                    repository.toggleLike(videoId, false)
                    v.copy(isLiked = true, likeCount = v.likeCount + 1)
                } else v
            }
            val newHeart = FlyingHeart(
                id = System.currentTimeMillis(),
                x = x,
                y = y,
                rotation = (-25..25).random().toFloat()
            )
            state.copy(
                videos = updated,
                flyingHearts = state.flyingHearts + newHeart
            )
        }
    }

    fun removeHeart(id: Long) {
        _uiState.update { state ->
            state.copy(flyingHearts = state.flyingHearts.filter { it.id != id })
        }
    }

    fun addComment(videoId: String, text: String) {
        if (text.isBlank()) return
        val updatedComments = repository.addComment(videoId, text.trim())
        _uiState.update { state ->
            val updatedVideos = state.videos.map { v ->
                if (v.id == videoId) {
                    v.copy(
                        comments = updatedComments,
                        commentCount = v.commentCount + 1
                    )
                } else v
            }
            state.copy(videos = updatedVideos)
        }
    }

    fun importUris(uris: List<Uri>) {
        viewModelScope.launch {
            if (uris.isEmpty()) return@launch
            _uiState.update { it.copy(isLoading = true) }
            val imported = repository.loadFromUris(uris)
            _uiState.update { state ->
                state.copy(
                    videos = imported + state.videos,
                    currentIndex = 0,
                    isLoading = false,
                    feedbackMessage = "Imported ${uris.size} videos successfully!"
                )
            }
        }
    }

    fun setTargetDirectory(path: String) {
        loadVideos(path)
    }

    fun generateSampleVideos() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val dir = File(_uiState.value.targetDirectory)
            SampleVideoGenerator.generateSampleVideosIfEmpty(dir)
            val refreshed = repository.loadAndShuffleVideos(_uiState.value.targetDirectory)
            _uiState.update {
                it.copy(
                    videos = refreshed,
                    currentIndex = 0,
                    isLoading = false,
                    feedbackMessage = "Generated offline test clips!"
                )
            }
        }
    }

    fun openFolderManager(open: Boolean) {
        _uiState.update { it.copy(showFolderManager = open) }
    }

    fun openComments(open: Boolean) {
        _uiState.update { it.copy(showCommentsSheet = open) }
    }

    fun openMusicSheet(open: Boolean) {
        _uiState.update { it.copy(showMusicSheet = open) }
    }

    fun openEditNotes(video: VideoItem? = null) {
        val target = video ?: _uiState.value.currentVideo
        _uiState.update {
            it.copy(
                showEditNotesSheet = target != null,
                videoToEdit = target
            )
        }
    }

    fun closeEditNotes() {
        _uiState.update {
            it.copy(
                showEditNotesSheet = false,
                videoToEdit = null
            )
        }
    }

    fun saveVideoNotes(
        videoId: String,
        newSoundTitle: String,
        newCaption: String,
        newAuthorHandle: String
    ) {
        val cleanSound = newSoundTitle.trim()
        val cleanCaption = newCaption.trim()
        val rawAuthor = newAuthorHandle.trim()
        val cleanAuthor = if (rawAuthor.isNotBlank()) {
            if (rawAuthor.startsWith("@")) rawAuthor else "@$rawAuthor"
        } else "@offline_creator"

        repository.saveVideoNotes(videoId, cleanSound, cleanCaption, cleanAuthor)

        _uiState.update { state ->
            val updatedVideos = state.videos.map { v ->
                if (v.id == videoId) {
                    v.copy(
                        soundTitle = cleanSound,
                        caption = cleanCaption,
                        authorHandle = cleanAuthor,
                        authorName = cleanAuthor.removePrefix("@"),
                        isBookmarked = true,
                        bookmarkCount = if (!v.isBookmarked) v.bookmarkCount + 1 else v.bookmarkCount
                    )
                } else v
            }
            state.copy(
                videos = updatedVideos,
                showEditNotesSheet = false,
                videoToEdit = null,
                feedbackMessage = "Catatan lagu & tagar berhasil disimpan! 🎵"
            )
        }
    }

    fun toggleSaveMusic(musicTitle: String) {
        _uiState.update { state ->
            val isAlreadySaved = state.savedMusics.contains(musicTitle)
            val nextSet = if (isAlreadySaved) {
                state.savedMusics - musicTitle
            } else {
                state.savedMusics + musicTitle
            }
            state.copy(
                savedMusics = nextSet,
                feedbackMessage = if (isAlreadySaved) "Musik dihapus dari Favorit" else "Musik disimpan ke Favorit 🎵"
            )
        }
    }

    fun updateVideoMusicName(videoId: String, newTitle: String) {
        if (newTitle.isBlank()) return
        _uiState.update { state ->
            val updated = state.videos.map { v ->
                if (v.id == videoId) v.copy(soundTitle = newTitle) else v
            }
            state.copy(
                videos = updated,
                feedbackMessage = "Nama musik berhasil diubah!"
            )
        }
    }

    fun openInfo(open: Boolean) {
        _uiState.update { it.copy(showInfoSheet = open) }
    }

    fun clearFeedbackMessage() {
        _uiState.update { it.copy(feedbackMessage = null) }
    }

    fun setPermissionGranted(granted: Boolean) {
        _uiState.update { it.copy(hasStoragePermission = granted) }
        if (granted) {
            loadVideos()
        }
    }
}
