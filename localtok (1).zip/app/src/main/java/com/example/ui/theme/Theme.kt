package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TikTokColorScheme = darkColorScheme(
    primary = TikTokRed,
    onPrimary = TikTokWhite,
    primaryContainer = TikTokDarkSurface,
    onPrimaryContainer = TikTokWhite,
    secondary = TikTokCyan,
    onSecondary = TikTokBlack,
    secondaryContainer = TikTokSurfaceVariant,
    onSecondaryContainer = TikTokCyan,
    tertiary = TikTokYellow,
    onTertiary = TikTokBlack,
    background = TikTokBlack,
    onBackground = TikTokWhite,
    surface = TikTokBlack,
    onSurface = TikTokWhite,
    surfaceVariant = TikTokDarkSurface,
    onSurfaceVariant = TikTokTextSecondary,
    outline = TikTokBorder,
    outlineVariant = Color(0x1FFFFFFF)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TikTokColorScheme,
        typography = Typography,
        content = content
    )
}
