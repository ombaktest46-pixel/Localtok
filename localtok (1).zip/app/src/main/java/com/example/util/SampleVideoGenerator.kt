package com.example.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.sin

object SampleVideoGenerator {
    private const val TAG = "SampleVideoGen"
    private const val WIDTH = 720
    private const val HEIGHT = 1280
    private const val BIT_RATE = 2_000_000
    private const val FRAME_RATE = 24
    private const val DURATION_SEC = 4
    private const val TOTAL_FRAMES = FRAME_RATE * DURATION_SEC

    data class VideoTheme(
        val title: String,
        val filename: String,
        val creator: String,
        val handle: String,
        val caption: String,
        val sound: String,
        val bgColor1: Int,
        val bgColor2: Int,
        val accentColor: Int
    )

    val SAMPLE_THEMES = listOf(
        VideoTheme(
            title = "KUIS BERHADIAH",
            filename = "kuis_berhadiah.mp4",
            creator = "yogreks",
            handle = "@yogreks",
            caption = "Tanya jawab 😭 #fyp #lol #prank #harmlessprank #momoyomilkteabattle",
            sound = "Original Sound - yogreks",
            bgColor1 = Color.rgb(60, 75, 85),
            bgColor2 = Color.rgb(35, 45, 55),
            accentColor = Color.rgb(0, 242, 254)
        ),
        VideoTheme(
            title = "Neon Glow Beats",
            filename = "neon_beats.mp4",
            creator = "CyberVibes",
            handle = "@cybervibes",
            caption = "Late night creative flow 🌙✨ #offline #vibes #synthwave #neon",
            sound = "Original Sound - CyberVibes (Night Mix)",
            bgColor1 = Color.rgb(15, 10, 30),
            bgColor2 = Color.rgb(30, 15, 60),
            accentColor = Color.rgb(0, 242, 254)
        ),
        VideoTheme(
            title = "Sunset Chill Drive",
            filename = "sunset_drive.mp4",
            creator = "AuraLens",
            handle = "@auralens",
            caption = "Golden hour magic from the coast 🌅🌊 Never gets old #goldenhour #aesthetic",
            sound = "Lo-Fi Coast - AuraLens Radio",
            bgColor1 = Color.rgb(60, 20, 30),
            bgColor2 = Color.rgb(20, 10, 40),
            accentColor = Color.rgb(254, 44, 85)
        )
    )

    suspend fun generateSampleVideosIfEmpty(targetDir: File): List<File> = withContext(Dispatchers.IO) {
        val createdFiles = mutableListOf<File>()
        try {
            if (!targetDir.exists()) {
                targetDir.mkdirs()
            }
            SAMPLE_THEMES.forEachIndexed { index, theme ->
                val file = File(targetDir, theme.filename)
                if (!file.exists() || file.length() == 0L) {
                    val success = generateMp4(file, theme, index)
                    if (success) {
                        createdFiles.add(file)
                    }
                } else {
                    createdFiles.add(file)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error generating sample clips: ${e.message}", e)
        }
        createdFiles
    }

    private fun generateMp4(outFile: File, theme: VideoTheme, themeIndex: Int): Boolean {
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        try {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, WIDTH, HEIGHT).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, BIT_RATE)
                setInteger(MediaFormat.KEY_FRAME_RATE, FRAME_RATE)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = codec.createInputSurface()
            codec.start()

            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var trackIndex = -1
            var muxerStarted = false

            val bufferInfo = MediaCodec.BufferInfo()
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)

            for (frame in 0 until TOTAL_FRAMES) {
                // Render frame onto surface
                val canvas: Canvas = surface.lockCanvas(null)
                try {
                    // Draw gradient background
                    val progress = frame.toFloat() / TOTAL_FRAMES
                    canvas.drawColor(theme.bgColor1)

                    // Draw subtle animated glowing rings
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 6f
                    val pulse = (sin(frame * 0.15) * 40).toFloat()
                    val cx = WIDTH / 2f
                    val cy = HEIGHT / 2f

                    paint.color = Color.argb(40, 255, 255, 255)
                    canvas.drawCircle(cx, cy, 180f + pulse, paint)

                    paint.color = theme.accentColor
                    paint.strokeWidth = 8f
                    canvas.drawCircle(cx, cy, 120f - pulse * 0.5f, paint)

                    // Draw inner card
                    paint.style = Paint.Style.FILL
                    paint.color = Color.argb(180, 20, 22, 34)
                    val cardRect = RectF(cx - 240f, cy - 140f, cx + 240f, cy + 140f)
                    canvas.drawRoundRect(cardRect, 32f, 32f, paint)

                    // Draw play icon or music note
                    paint.color = theme.accentColor
                    paint.style = Paint.Style.FILL
                    val path = android.graphics.Path().apply {
                        moveTo(cx - 30f, cy - 50f)
                        lineTo(cx + 40f, cy)
                        lineTo(cx - 30f, cy + 50f)
                        close()
                    }
                    canvas.drawPath(path, paint)

                    if (theme.title == "KUIS BERHADIAH") {
                        // Draw city street & motorcyclists scene
                        // Road surface
                        paint.style = Paint.Style.FILL
                        paint.color = Color.rgb(45, 48, 55)
                        canvas.drawRect(0f, cy, WIDTH.toFloat(), HEIGHT.toFloat(), paint)

                        // Red zebra crosswalk area
                        paint.color = Color.rgb(180, 40, 45)
                        canvas.drawRect(0f, cy + 80f, WIDTH.toFloat(), cy + 220f, paint)

                        // Motorbike shapes & helmets
                        val ridersX = listOf(140f, 260f, 380f, 500f, 620f)
                        val helmetColors = listOf(Color.BLACK, Color.rgb(200, 50, 40), Color.rgb(220, 120, 30), Color.rgb(40, 160, 90), Color.BLACK)
                        ridersX.forEachIndexed { i, rx ->
                            // Helmet
                            paint.color = helmetColors[i % helmetColors.size]
                            canvas.drawCircle(rx, cy + 20f + (sin(frame * 0.1 + i) * 3).toFloat(), 28f, paint)
                            // Motorbike body
                            paint.color = Color.rgb(30, 30, 35)
                            canvas.drawRoundRect(RectF(rx - 32f, cy + 55f, rx + 32f, cy + 180f), 12f, 12f, paint)
                            // Headlight
                            paint.color = Color.rgb(255, 255, 200)
                            canvas.drawCircle(rx, cy + 85f, 12f, paint)
                        }

                        // Sky & Billboard in background
                        paint.color = Color.rgb(135, 185, 220)
                        canvas.drawRect(0f, 0f, WIDTH.toFloat(), cy, paint)
                        paint.color = Color.rgb(70, 130, 180)
                        canvas.drawRect(80f, cy - 260f, 240f, cy - 140f, paint) // Billboard

                        // Sticker: [KUIS] BERHADIAH matching screenshot!
                        val stickerY = cy + 290f
                        // [KUIS] Box: Cyan with black border
                        paint.style = Paint.Style.FILL
                        paint.color = Color.rgb(0, 242, 254)
                        val kuisRect = RectF(cx - 190f, stickerY - 32f, cx - 40f, stickerY + 22f)
                        canvas.drawRoundRect(kuisRect, 8f, 8f, paint)
                        paint.style = Paint.Style.STROKE
                        paint.color = Color.BLACK
                        paint.strokeWidth = 4f
                        canvas.drawRoundRect(kuisRect, 8f, 8f, paint)

                        // "KUIS" text
                        paint.style = Paint.Style.FILL
                        paint.color = Color.BLACK
                        paint.textSize = 34f
                        paint.isFakeBoldText = true
                        paint.textAlign = Paint.Align.CENTER
                        canvas.drawText("KUIS", cx - 115f, stickerY + 8f, paint)

                        // "BERHADIAH" text with black outline/shadow
                        paint.style = Paint.Style.STROKE
                        paint.color = Color.BLACK
                        paint.strokeWidth = 8f
                        paint.textSize = 36f
                        canvas.drawText("BERHADIAH", cx + 90f, stickerY + 9f, paint)

                        paint.style = Paint.Style.FILL
                        paint.color = Color.WHITE
                        canvas.drawText("BERHADIAH", cx + 90f, stickerY + 9f, paint)
                    } else {
                        // Draw title text
                        paint.color = Color.WHITE
                        paint.textSize = 38f
                        paint.textAlign = Paint.Align.CENTER
                        paint.isFakeBoldText = true
                        canvas.drawText(theme.title, cx, cy + 90f, paint)

                        // Draw handle & offline badge
                        paint.textSize = 24f
                        paint.color = Color.argb(200, 255, 255, 255)
                        paint.isFakeBoldText = false
                        canvas.drawText("${theme.handle} • Offline TikTok", cx, cy + 120f, paint)
                    }

                    // Draw top bar preview badge
                    paint.color = Color.argb(160, 0, 0, 0)
                    canvas.drawRoundRect(RectF(cx - 160f, 100f, cx + 160f, 160f), 20f, 20f, paint)
                    paint.color = Color.WHITE
                    paint.textSize = 26f
                    canvas.drawText("OFFLINE FYP DEMO", cx, 142f, paint)

                    // Draw animated progress bar at bottom
                    paint.color = Color.argb(100, 255, 255, 255)
                    canvas.drawRect(0f, HEIGHT - 10f, WIDTH.toFloat(), HEIGHT.toFloat(), paint)
                    paint.color = theme.accentColor
                    canvas.drawRect(0f, HEIGHT - 10f, WIDTH * progress, HEIGHT.toFloat(), paint)

                } finally {
                    surface.unlockCanvasAndPost(canvas)
                }

                // Drain encoder
                while (true) {
                    val outputBufferId = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                    if (outputBufferId == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        break
                    } else if (outputBufferId == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (muxerStarted) {
                            throw RuntimeException("Format changed after muxer started")
                        }
                        val newFormat = codec.outputFormat
                        trackIndex = muxer.addTrack(newFormat)
                        muxer.start()
                        muxerStarted = true
                    } else if (outputBufferId >= 0) {
                        val encodedData = codec.getOutputBuffer(outputBufferId)
                        if (encodedData != null && bufferInfo.size > 0 && muxerStarted) {
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                        }
                        codec.releaseOutputBuffer(outputBufferId, false)
                    }
                }
            }

            codec.signalEndOfInputStream()

            // Drain remaining EOS
            var sawInputEOS = true
            while (sawInputEOS) {
                val outputBufferId = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputBufferId >= 0) {
                    val encodedData = codec.getOutputBuffer(outputBufferId)
                    if (encodedData != null && bufferInfo.size > 0 && muxerStarted) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                    }
                    codec.releaseOutputBuffer(outputBufferId, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        sawInputEOS = false
                    }
                } else if (outputBufferId == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    sawInputEOS = false
                }
            }

            return true
        } catch (e: Exception) {
            Log.e(TAG, "Failed creating MP4 for ${theme.filename}: ${e.message}")
            return false
        } finally {
            try {
                codec?.stop()
                codec?.release()
                muxer?.stop()
                muxer?.release()
            } catch (e: Exception) {
                // Ignore cleanup errors
            }
        }
    }
}
