package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.rotate
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.border
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.ui.AspectRatioFrameLayout
import com.example.ui.components.EditVideoNotesSheet
import com.example.ui.components.FlyingHeartItem
import com.example.ui.components.FolderManagerSheet
import com.example.ui.components.MusicDetailsSheet
import com.example.ui.components.TikTokActionsColumn
import com.example.ui.components.TikTokBottomNavBar
import com.example.ui.components.TikTokBottomOverlay
import com.example.ui.components.TikTokCommentsSheet
import com.example.ui.components.TikTokVideoScrubber
import com.example.ui.components.VideoInfoSheet
import com.example.ui.components.VideoPlayerView
import com.example.ui.theme.TikTokBlack
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokDarkSurface
import com.example.ui.theme.TikTokRed
import com.example.ui.theme.TikTokTextSecondary
import com.example.ui.theme.TikTokWhite
import com.example.ui.viewmodel.TikTokViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun TikTokFeedScreen(
    viewModel: TikTokViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()

    // File picker launcher
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.importUris(uris)
        }
    }

    // Auto-clear feedback toast message after 2.5 seconds
    LaunchedEffect(uiState.feedbackMessage) {
        if (uiState.feedbackMessage != null) {
            delay(2500)
            viewModel.clearFeedbackMessage()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(TikTokBlack)
    ) {
        if (uiState.videos.isEmpty() && !uiState.isLoading) {
            // Empty State
            EmptyOfflineState(
                currentPath = uiState.targetDirectory,
                onGenerateClips = { viewModel.generateSampleVideos() },
                onOpenFolderManager = { viewModel.openFolderManager(true) },
                onImportVideos = { videoPickerLauncher.launch("video/*") }
            )
        } else if (uiState.isLoading && uiState.videos.isEmpty()) {
            // Loading
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = TikTokRed)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Scanning & Shuffling Offline FYP...",
                        color = TikTokWhite,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            // Vertical Pager with full-screen TikTok videos
            val pagerState = rememberPagerState(
                initialPage = uiState.currentIndex,
                pageCount = { uiState.videos.size }
            )

            // Sync pager state with ViewModel
            LaunchedEffect(pagerState) {
                snapshotFlow { pagerState.currentPage }.collect { page ->
                    viewModel.onPageChanged(page)
                }
            }

            // Sync ViewModel index changes with pager (e.g. after shuffle)
            LaunchedEffect(uiState.currentIndex) {
                if (pagerState.currentPage != uiState.currentIndex && uiState.currentIndex < uiState.videos.size) {
                    pagerState.scrollToPage(uiState.currentIndex)
                }
            }

            var currentVideoProgress by remember { mutableFloatStateOf(0f) }
            var currentVideoMs by remember { mutableLongStateOf(0L) }
            var currentVideoDurationMs by remember { mutableLongStateOf(15000L) }
            var globalSeekTargetMs by remember { mutableStateOf<Long?>(null) }

            LaunchedEffect(pagerState.currentPage, uiState.videos) {
                currentVideoProgress = 0f
                currentVideoMs = 0L
                val cur = uiState.videos.getOrNull(pagerState.currentPage)
                if (cur != null) {
                    currentVideoDurationMs = cur.durationMs
                }
            }

            VerticalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                val video = uiState.videos[page]
                val isCurrentPage = pagerState.currentPage == page

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(uiState.isClearDisplay) {
                            detectTapGestures(
                                onTap = {
                                    if (uiState.isClearDisplay) {
                                        viewModel.setClearDisplay(false)
                                    } else {
                                        viewModel.togglePlayPause()
                                    }
                                },
                                onDoubleTap = { offset ->
                                    viewModel.onDoubleTapLike(video.id, offset.x, offset.y)
                                },
                                onLongPress = {
                                    viewModel.toggleClearDisplay()
                                }
                            )
                        }
                ) {
                    // Video Player (with authentic Aspect Ratio Fit by default)
                    VideoPlayerView(
                        videoUri = video.uri,
                        isCurrentPage = isCurrentPage,
                        isPlaying = uiState.isPlaying,
                        isMuted = uiState.isMuted,
                        isLooping = uiState.isLoopEnabled,
                        resizeMode = uiState.resizeMode,
                        seekToMs = if (isCurrentPage) globalSeekTargetMs else null,
                        onSeekCompleted = {
                            if (isCurrentPage) globalSeekTargetMs = null
                        },
                        onVideoEnded = {
                            if (!uiState.isLoopEnabled) {
                                if (page + 1 < uiState.videos.size) {
                                    scope.launch {
                                        pagerState.animateScrollToPage(page + 1)
                                    }
                                }
                            }
                        },
                        onProgressUpdate = { prog, cur, dur ->
                            if (isCurrentPage) {
                                currentVideoProgress = prog
                                currentVideoMs = cur
                                currentVideoDurationMs = dur
                            }
                        }
                    )

                    // Overlays: only visible when Layar Bersih (Clear Display) is not active
                    AnimatedVisibility(
                        visible = !uiState.isClearDisplay,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            // Right-side authentic TikTok action buttons
                            TikTokActionsColumn(
                                video = video,
                                isPlaying = uiState.isPlaying,
                                onLikeClick = { viewModel.toggleLike(video.id) },
                                onCommentClick = { viewModel.openComments(true) },
                                onBookmarkClick = { viewModel.openEditNotes(video) },
                                onShareClick = { viewModel.openInfo(true) },
                                onMusicClick = { viewModel.openMusicSheet(true) },
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .navigationBarsPadding()
                                    .padding(bottom = 155.dp, end = 8.dp)
                            )

                            // Bottom metadata overlay (Author handle, description/tags, music sound)
                            TikTokBottomOverlay(
                                video = video,
                                progress = currentVideoProgress,
                                currentMs = currentVideoMs,
                                durationMs = currentVideoDurationMs,
                                onMusicClick = { viewModel.openMusicSheet(true) },
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .navigationBarsPadding()
                                    .padding(bottom = 155.dp, start = 12.dp, end = 76.dp)
                            )
                        }
                    }
                }
            }

            // Top Bar Overlay (Hidden in Layar Bersih mode)
            AnimatedVisibility(
                visible = !uiState.isClearDisplay,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
            ) {
                TikTokTopBar(
                    selectedTab = uiState.selectedTab,
                    onTabSelected = { viewModel.setSelectedTab(it) },
                    onShuffleClick = { viewModel.shuffleFyp() },
                    onFolderClick = { viewModel.openFolderManager(true) },
                    onAddVideoClick = { videoPickerLauncher.launch("video/*") }
                )
            }

            // Video Scrubber & Bottom Navigation Bar (Hidden in Layar Bersih mode)
            AnimatedVisibility(
                visible = !uiState.isClearDisplay,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                ) {
                    // 1. Floating Video Duration Scrubber Capsule (Elevated 44dp above the bottom navigation bar)
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = Color.Black.copy(alpha = 0.85f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                        shadowElevation = 8.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                            .padding(bottom = 44.dp)
                    ) {
                        TikTokVideoScrubber(
                            progress = currentVideoProgress,
                            currentMs = currentVideoMs,
                            durationMs = currentVideoDurationMs,
                            onSeek = { targetMs ->
                                globalSeekTargetMs = targetMs
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    // 2. Bottom Navigation Bar (Beranda, Toko, +, Kotak Masuk, Profil)
                    TikTokBottomNavBar(
                        selectedTab = uiState.selectedNav,
                        onTabSelected = { nav ->
                            viewModel.setSelectedNav(nav)
                            if (nav == "Teman" || nav == "Toko") {
                                viewModel.shuffleFyp()
                            } else if (nav == "Profil") {
                                viewModel.openFolderManager(true)
                            }
                        },
                        onAddClick = {
                            videoPickerLauncher.launch("video/*")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black)
                    )
                }
            }
        }

        // Flying hearts layer for double-tap likes
        uiState.flyingHearts.forEach { heart ->
            FlyingHeartItem(
                heart = heart,
                onAnimationEnd = { id -> viewModel.removeHeart(id) }
            )
        }

        // Feedback floating toast
        AnimatedVisibility(
            visible = uiState.feedbackMessage != null,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 54.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.85f))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = uiState.feedbackMessage ?: "",
                    color = TikTokWhite,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }
        }

        // Modals & Bottom Sheets
        if (uiState.showCommentsSheet && uiState.currentVideo != null) {
            TikTokCommentsSheet(
                comments = uiState.currentVideo!!.comments,
                onDismiss = { viewModel.openComments(false) },
                onAddComment = { text ->
                    viewModel.addComment(uiState.currentVideo!!.id, text)
                }
            )
        }

        if (uiState.showFolderManager) {
            FolderManagerSheet(
                currentPath = uiState.targetDirectory,
                videoCount = uiState.videos.size,
                onDismiss = { viewModel.openFolderManager(false) },
                onPathChanged = { path -> viewModel.setTargetDirectory(path) },
                onRescan = { viewModel.loadVideos() },
                onShuffleFyp = { viewModel.shuffleFyp() },
                onGenerateDemoClips = { viewModel.generateSampleVideos() },
                onPickVideosFromDevice = {
                    videoPickerLauncher.launch("video/*")
                    viewModel.openFolderManager(false)
                }
            )
        }

        if (uiState.showInfoSheet) {
            VideoInfoSheet(
                video = uiState.currentVideo,
                onDismiss = { viewModel.openInfo(false) }
            )
        }

        if (uiState.showMusicSheet) {
            MusicDetailsSheet(
                video = uiState.currentVideo,
                savedMusics = uiState.savedMusics,
                onDismiss = { viewModel.openMusicSheet(false) },
                onToggleSave = { title -> viewModel.toggleSaveMusic(title) },
                onRenameMusic = { videoId, newName -> viewModel.updateVideoMusicName(videoId, newName) }
            )
        }

        if (uiState.showEditNotesSheet && (uiState.videoToEdit ?: uiState.currentVideo) != null) {
            val target = uiState.videoToEdit ?: uiState.currentVideo!!
            EditVideoNotesSheet(
                video = target,
                onDismiss = { viewModel.closeEditNotes() },
                onSaveNotes = { soundTitle, caption, authorHandle ->
                    viewModel.saveVideoNotes(target.id, soundTitle, caption, authorHandle)
                }
            )
        }
    }
}

@Composable
private fun TikTokTopBar(
    selectedTab: String,
    onTabSelected: (String) -> Unit,
    onShuffleClick: () -> Unit,
    onFolderClick: () -> Unit,
    onAddVideoClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left: Authentic LIVE TV icon with antennas matching screenshot
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .clickable(onClick = onFolderClick)
                .padding(end = 6.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(bottom = 1.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(1.5.dp)
                        .height(3.5.dp)
                        .rotate(-20f)
                        .background(TikTokWhite)
                )
                Box(
                    modifier = Modifier
                        .width(1.5.dp)
                        .height(3.5.dp)
                        .rotate(20f)
                        .background(TikTokWhite)
                )
            }
            Box(
                modifier = Modifier
                    .border(1.5.dp, TikTokWhite, RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "LIVE",
                    color = TikTokWhite,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // Center: 4 Authentic Tabs from screenshot: Pasuruan | Teman | Mengikuti | Saran
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            TopTabItem(
                title = "Pasuruan",
                isSelected = selectedTab == "Pasuruan",
                onClick = { onTabSelected("Pasuruan") }
            )
            TopTabItem(
                title = "Teman",
                isSelected = selectedTab == "Teman",
                onClick = { onTabSelected("Teman") }
            )
            TopTabItem(
                title = "Mengikuti",
                isSelected = selectedTab == "Mengikuti",
                onClick = { onTabSelected("Mengikuti") }
            )
            TopTabItem(
                title = "Saran",
                isSelected = selectedTab == "Saran",
                onClick = { onTabSelected("Saran") }
            )
        }

        // Right: Search Icon matching screenshot
        IconButton(
            onClick = onShuffleClick,
            modifier = Modifier
                .size(34.dp)
                .testTag("top_search_button")
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Cari",
                tint = TikTokWhite,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
private fun TopTabItem(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = title,
            color = if (isSelected) TikTokWhite else TikTokWhite.copy(alpha = 0.6f),
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 15.sp
        )

        Spacer(modifier = Modifier.height(3.dp))

        // White underline bar for active tab (matching screenshot!)
        if (isSelected) {
            Box(
                modifier = Modifier
                    .width(26.dp)
                    .height(2.5.dp)
                    .clip(RoundedCornerShape(1.dp))
                    .background(TikTokWhite)
            )
        } else {
            Spacer(modifier = Modifier.height(2.5.dp))
        }
    }
}

@Composable
private fun EmptyOfflineState(
    currentPath: String,
    onGenerateClips: () -> Unit,
    onOpenFolderManager: () -> Unit,
    onImportVideos: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(TikTokDarkSurface),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Movie,
                contentDescription = null,
                tint = TikTokRed,
                modifier = Modifier.size(46.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Belum Ada Video Offline",
            color = TikTokWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Mencari video di folder:\n$currentPath\n\nMasukkan video dengan rasio 4:3, 16:9, atau 9:16 untuk diputar otomatis!",
            color = TikTokTextSecondary,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onGenerateClips,
            colors = ButtonDefaults.buttonColors(containerColor = TikTokRed),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("generate_demo_button")
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                tint = TikTokWhite,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Generate 3 Demo FYP Clips",
                color = TikTokWhite,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = onImportVideos,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TikTokCyan),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "Pilih Video dari HP / Galeri")
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = onOpenFolderManager,
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TikTokWhite),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Folder,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "Kelola Folder Penyimpanan")
        }
    }
}
