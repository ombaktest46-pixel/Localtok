package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.ModeComment
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VideoItem
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokRed
import com.example.ui.theme.TikTokWhite
import com.example.ui.theme.TikTokYellow
import java.util.Locale

@Composable
fun TikTokActionsColumn(
    video: VideoItem,
    isPlaying: Boolean,
    onLikeClick: () -> Unit,
    onCommentClick: () -> Unit,
    onBookmarkClick: () -> Unit,
    onShareClick: () -> Unit,
    onMusicClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Like button bounce animation
    var likedTrigger by remember { mutableStateOf(false) }
    val heartScale by animateFloatAsState(
        targetValue = if (likedTrigger) 1.35f else 1.0f,
        animationSpec = tween(durationMillis = 160, easing = FastOutSlowInEasing),
        finishedListener = { likedTrigger = false },
        label = "heartScale"
    )

    // Rotating vinyl record animation
    val infiniteTransition = rememberInfiniteTransition(label = "discRotate")
    val discRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "discRotation"
    )

    Column(
        modifier = modifier.padding(end = 8.dp, bottom = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Upper translucent icons (as seen in screenshot)
        // 1. Flag icon (Laporkan / Bookmark mode)
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.35f))
                .clickable(onClick = onShareClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.Flag,
                contentDescription = "Laporkan / Penanda",
                tint = TikTokWhite,
                modifier = Modifier.size(19.dp)
            )
        }

        // 2. Q&A / Tanya Jawab bubble icon (as seen in screenshot above creator avatar)
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.35f))
                .clickable(onClick = onCommentClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.ModeComment,
                contentDescription = "Tanya Jawab",
                tint = TikTokWhite,
                modifier = Modifier.size(18.dp)
            )
        }

        // 3. Creator Avatar with Red '+' Follow Button
        CreatorAvatar(authorHandle = video.authorHandle)

        // 2. Like (Heart) Button
        ActionButtonWithLabel(
            icon = Icons.Default.Favorite,
            label = formatTikTokCount(video.likeCount),
            tint = if (video.isLiked) TikTokRed else TikTokWhite,
            contentDescription = "Suka",
            testTag = "like_button",
            modifier = Modifier.scale(heartScale),
            onClick = {
                likedTrigger = true
                onLikeClick()
            }
        )

        // 3. Comments Button
        ActionButtonWithLabel(
            icon = Icons.Default.ChatBubble,
            label = formatTikTokCount(video.commentCount),
            tint = TikTokWhite,
            contentDescription = "Komentar",
            testTag = "comment_button",
            onClick = onCommentClick
        )

        // 4. Bookmark / Favorite / Edit Music & Tag Notes Button
        ActionButtonWithLabel(
            icon = Icons.Default.Bookmark,
            label = if (video.isBookmarked) "Catatan" else "Catat",
            tint = if (video.isBookmarked) TikTokYellow else TikTokWhite,
            contentDescription = "Ubah Catatan Lagu & Tagar",
            testTag = "bookmark_button",
            onClick = onBookmarkClick
        )

        // 5. Share Button (TikTok right-curved arrow)
        ActionButtonWithLabel(
            icon = Icons.AutoMirrored.Filled.Reply,
            label = formatTikTokCount(video.shareCount.coerceAtLeast(14)),
            tint = TikTokWhite,
            contentDescription = "Bagikan",
            testTag = "share_button",
            iconModifier = Modifier.rotate(180f),
            onClick = onShareClick
        )

        // 6. Rotating Music Vinyl Disc with Author Avatar inside (Matching screenshot!)
        RotatingVinylDisc(
            authorHandle = video.authorHandle,
            rotationAngle = if (isPlaying) discRotation else 0f,
            onClick = onMusicClick
        )
    }
}

@Composable
private fun CreatorAvatar(authorHandle: String) {
    var isFollowed by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.size(54.dp),
        contentAlignment = Alignment.Center
    ) {
        // Circular Avatar with border matching screenshot
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .border(1.5.dp, TikTokWhite, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            CreatorAvatarContent(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
            )
        }

        // Red '+' Follow Badge at bottom
        if (!isFollowed) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(TikTokRed)
                    .clickable { isFollowed = true },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Ikuti",
                    tint = TikTokWhite,
                    modifier = Modifier.size(13.dp)
                )
            }
        }
    }
}

@Composable
fun CreatorAvatarContent(modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Sky & city street backdrop
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF87CEEB), // Blue sky
                    Color(0xFFE8EEF5), // Horizon
                    Color(0xFF888888), // Pavement/cars
                    Color(0xFF333333)
                )
            )
        )
        // Red car silhouette on right
        drawRoundRect(
            color = Color(0xFFC62828),
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.72f, h * 0.44f),
            size = androidx.compose.ui.geometry.Size(w * 0.28f, h * 0.2f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
        )
        // Head / face
        drawCircle(
            color = Color(0xFFD8B08A),
            radius = w * 0.20f,
            center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.35f)
        )
        // Dark hair
        drawArc(
            color = Color(0xFF1A1A1A),
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.30f, h * 0.15f),
            size = androidx.compose.ui.geometry.Size(w * 0.40f, h * 0.25f)
        )
        // Blue navy jacket with zipper line
        drawOval(
            color = Color(0xFF1E3A5F),
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.16f, h * 0.52f),
            size = androidx.compose.ui.geometry.Size(w * 0.68f, h * 0.56f)
        )
        // Silver zipper
        drawLine(
            color = Color(0xFFD1D5DB),
            start = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.52f),
            end = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.95f),
            strokeWidth = 2.5f
        )
    }
}

@Composable
private fun ActionButtonWithLabel(
    icon: ImageVector,
    label: String,
    tint: Color,
    contentDescription: String,
    testTag: String,
    modifier: Modifier = Modifier,
    iconModifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = ripple(bounded = false, radius = 24.dp),
            onClick = onClick
        ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .testTag(testTag),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = tint,
                modifier = iconModifier.size(32.dp)
            )
        }
        Text(
            text = label,
            color = TikTokWhite,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
private fun RotatingVinylDisc(
    authorHandle: String,
    rotationAngle: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Color.Black)
            .border(2.dp, Color(0xFF222222), CircleShape)
            .rotate(rotationAngle)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = 26.dp),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        // Disc grooves
        Box(
            modifier = Modifier
                .size(34.dp)
                .border(1.dp, Color(0xFF333338), CircleShape)
        )
        // Center creator avatar inside vinyl disc (matching screenshot)
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape),
            contentAlignment = Alignment.Center
        ) {
            CreatorAvatarContent(modifier = Modifier.size(24.dp))
        }
    }
}

private fun formatTikTokCount(count: Int): String {
    return when {
        count >= 1_000_000 -> String.format(Locale("in", "ID"), "%.1f jt", count / 1_000_000.0)
        count >= 10_000 -> String.format(Locale("in", "ID"), "%.1f rb", count / 1_000.0)
        count >= 1_000 -> String.format(Locale("in", "ID"), "%,d", count).replace(',', '.')
        else -> count.toString()
    }
}
