package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokTextSecondary
import com.example.ui.theme.TikTokWhite
import java.util.Locale

@Composable
fun TikTokVideoScrubber(
    progress: Float,
    currentMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var isDragging by remember { mutableStateOf(false) }
    var dragProgress by remember { mutableFloatStateOf(0f) }
    val density = LocalDensity.current

    val effectiveProgress = if (isDragging) dragProgress else progress.coerceIn(0f, 1f)
    val displayCurrentMs = if (isDragging) {
        (dragProgress * durationMs).toLong().coerceIn(0L, durationMs)
    } else {
        currentMs.coerceIn(0L, durationMs)
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(38.dp)
            .padding(horizontal = 8.dp)
            .testTag("video_seek_scrubber"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Quick rewind 10s button
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.White.copy(alpha = 0.18f),
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable {
                    val target = (currentMs - 10000L).coerceAtLeast(0L)
                    onSeek(target)
                }
        ) {
            Text(
                text = "-10s",
                color = TikTokWhite,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 5.dp, vertical = 3.dp)
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Current elapsed time
        Text(
            text = formatDuration(displayCurrentMs),
            color = TikTokWhite,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.width(34.dp)
        )

        Spacer(modifier = Modifier.width(6.dp))

        // Center interactive track and thumb
        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .height(38.dp)
                .pointerInput(durationMs) {
                    detectTapGestures(
                        onTap = { offset ->
                            val widthPx = size.width.toFloat()
                            if (widthPx > 0f && durationMs > 0L) {
                                val tappedProgress = (offset.x / widthPx).coerceIn(0f, 1f)
                                val targetMs = (tappedProgress * durationMs).toLong()
                                onSeek(targetMs)
                            }
                        }
                    )
                }
                .pointerInput(durationMs) {
                    detectHorizontalDragGestures(
                        onDragStart = { offset ->
                            isDragging = true
                            val widthPx = size.width.toFloat()
                            if (widthPx > 0f) {
                                dragProgress = (offset.x / widthPx).coerceIn(0f, 1f)
                                if (durationMs > 0L) {
                                    val targetMs = (dragProgress * durationMs).toLong()
                                    onSeek(targetMs)
                                }
                            }
                        },
                        onDragEnd = {
                            if (durationMs > 0L) {
                                val targetMs = (dragProgress * durationMs).toLong()
                                onSeek(targetMs)
                            }
                            isDragging = false
                        },
                        onDragCancel = {
                            isDragging = false
                        },
                        onHorizontalDrag = { change, _ ->
                            change.consume()
                            val widthPx = size.width.toFloat()
                            if (widthPx > 0f) {
                                dragProgress = (change.position.x / widthPx).coerceIn(0f, 1f)
                                if (durationMs > 0L) {
                                    val targetMs = (dragProgress * durationMs).toLong()
                                    onSeek(targetMs)
                                }
                            }
                        }
                    )
                },
            contentAlignment = Alignment.CenterStart
        ) {
            val totalWidth = maxWidth
            val currentWidth = totalWidth * effectiveProgress
            val trackHeight = if (isDragging) 5.dp else 3.dp
            val thumbSize = if (isDragging) 18.dp else 10.dp

            // Floating timestamp pill popup when user is actively dragging/scrubbing
            androidx.compose.animation.AnimatedVisibility(
                visible = isDragging,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (-36).dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.Black.copy(alpha = 0.9f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TikTokCyan.copy(alpha = 0.6f)),
                    shadowElevation = 6.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formatDuration(displayCurrentMs),
                            color = TikTokCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = " / ${formatDuration(durationMs)}",
                            color = TikTokWhite,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }
                }
            }

            // 1. Inactive full-width background track
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(trackHeight)
                    .clip(RoundedCornerShape(trackHeight / 2))
                    .background(Color.White.copy(alpha = if (isDragging) 0.35f else 0.25f))
            )

            // 2. Active played progress track
            Box(
                modifier = Modifier
                    .width(currentWidth)
                    .height(trackHeight)
                    .clip(RoundedCornerShape(trackHeight / 2))
                    .background(if (isDragging) TikTokCyan else TikTokWhite)
            )

            // 3. Interactive scrubber thumb circle
            Box(
                modifier = Modifier
                    .offset(x = (currentWidth - (thumbSize / 2)).coerceIn(0.dp, totalWidth - thumbSize))
                    .size(thumbSize)
                    .clip(CircleShape)
                    .background(TikTokWhite)
                    .then(
                        if (isDragging) Modifier.border(2.5.dp, TikTokCyan, CircleShape)
                        else Modifier.border(1.dp, Color.Black.copy(alpha = 0.4f), CircleShape)
                    )
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Total video duration
        Text(
            text = formatDuration(durationMs),
            color = TikTokTextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Normal,
            modifier = Modifier.width(34.dp)
        )

        Spacer(modifier = Modifier.width(6.dp))

        // Quick forward 10s button
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.White.copy(alpha = 0.18f),
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable {
                    val target = (currentMs + 10000L).coerceAtMost(durationMs)
                    onSeek(target)
                }
        ) {
            Text(
                text = "+10s",
                color = TikTokWhite,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 5.dp, vertical = 3.dp)
            )
        }
    }
}

private fun formatDuration(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
}
