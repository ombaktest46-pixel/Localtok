package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TikTokBlack = Color(0xFF0D0D11)
val TikTokDarkSurface = Color(0xFF161823)
val TikTokSurfaceVariant = Color(0xFF242738)
val TikTokRed = Color(0xFFFE2C55)
val TikTokCyan = Color(0xFF25F4EE)
val TikTokWhite = Color(0xFFFFFFFF)
val TikTokTextSecondary = Color(0xCCFFFFFF)
val TikTokTextTertiary = Color(0x80FFFFFF)
val TikTokOverlay = Color(0x66000000)
val TikTokBorder = Color(0x33FFFFFF)
val TikTokYellow = Color(0xFFFFD700)

