package com.example.data.repository

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.util.Log
import androidx.core.net.toUri
import com.example.data.model.CommentItem
import com.example.data.model.VideoItem
import com.example.util.SampleVideoGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Random

class VideoRepository(private val context: Context) {
    companion object {
        private const val TAG = "VideoRepository"
        const val DEFAULT_FOLDER_PATH = "/storage/emulated/0/Download/TikTokOffline/"
        private const val PREFS_NAME = "tiktok_offline_prefs"
        private const val KEY_SAVED_PATH = "saved_target_directory"
        private val VIDEO_EXTENSIONS = setOf("mp4", "mkv", "webm", "mov", "3gp")

        /**
         * Cleans user input paths (removes quotes, fixes missing leading slashes, ensures valid dir format).
         */
        fun sanitizePath(input: String): String {
            var p = input.trim()
                .replace("'", "")
                .replace("\"", "")
                .trim()
            if (p.startsWith("storage/")) {
                p = "/$p"
            }
            if (p.isNotBlank() && !p.endsWith("/") && !p.substringAfterLast("/").contains(".")) {
                p = "$p/"
            }
            return if (p.isBlank()) DEFAULT_FOLDER_PATH else p
        }
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val likedVideoIds = mutableSetOf<String>()
    private val localComments = mutableMapOf<String, MutableList<CommentItem>>()

    /**
     * Gets the user's saved target directory path from persistent storage.
     */
    fun getSavedDirectoryPath(): String {
        val saved = prefs.getString(KEY_SAVED_PATH, null)
        return if (!saved.isNullOrBlank()) {
            sanitizePath(saved)
        } else {
            DEFAULT_FOLDER_PATH
        }
    }

    /**
     * Persists the target directory path so it stays saved across app restarts and reboots.
     */
    fun saveDirectoryPath(path: String) {
        val clean = sanitizePath(path)
        prefs.edit().putString(KEY_SAVED_PATH, clean).apply()
        Log.d(TAG, "Persisted target directory: $clean")
    }

    /**
     * Persists custom notes, sound title, and hashtags for a specific video.
     */
    fun saveVideoNotes(id: String, soundTitle: String, caption: String, authorHandle: String) {
        prefs.edit()
            .putString("video_sound_$id", soundTitle.trim())
            .putString("video_caption_$id", caption.trim())
            .putString("video_author_$id", authorHandle.trim())
            .putBoolean("video_bookmarked_$id", true)
            .apply()
        Log.d(TAG, "Saved custom notes for video $id: sound=$soundTitle")
    }

    fun getSavedSoundTitle(id: String): String? = prefs.getString("video_sound_$id", null)
    fun getSavedCaption(id: String): String? = prefs.getString("video_caption_$id", null)
    fun getSavedAuthor(id: String): String? = prefs.getString("video_author_$id", null)
    fun isVideoBookmarked(id: String): Boolean = prefs.getBoolean("video_bookmarked_$id", false)

    /**
     * Resolves the primary directory to look for offline TikTok videos.
     */
    fun getDefaultDirectory(): File {
        val savedPath = getSavedDirectoryPath()
        val directPath = File(savedPath)
        if (directPath.exists() && directPath.isDirectory) {
            return directPath
        }

        val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val tiktokFolder = File(downloads, "TikTokOffline")
        if (!tiktokFolder.exists()) {
            tiktokFolder.mkdirs()
        }
        return tiktokFolder
    }

    /**
     * Scans the given directory or default directory for video files.
     * If empty, automatically populates with high-fidelity offline sample videos.
     * Applies the FYP Shuffle algorithm.
     */
    suspend fun loadAndShuffleVideos(customPath: String? = null): List<VideoItem> = withContext(Dispatchers.IO) {
        val targetDir = if (!customPath.isNullOrBlank()) {
            val file = File(customPath)
            if (!file.exists()) file.mkdirs()
            file
        } else {
            getDefaultDirectory()
        }

        val videoFiles = mutableListOf<File>()

        try {
            if (targetDir.exists() && targetDir.isDirectory) {
                targetDir.listFiles()?.forEach { file ->
                    if (file.isFile && file.length() > 0 && VIDEO_EXTENSIONS.contains(file.extension.lowercase())) {
                        videoFiles.add(file)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error listing files from ${targetDir.absolutePath}: ${e.message}")
        }

        // If primary folder is empty, also check app external files directory
        if (videoFiles.isEmpty()) {
            val fallbackDir = context.getExternalFilesDir("TikTokOffline") ?: File(context.filesDir, "TikTokOffline")
            if (!fallbackDir.exists()) fallbackDir.mkdirs()

            fallbackDir.listFiles()?.forEach { file ->
                if (file.isFile && file.length() > 0 && VIDEO_EXTENSIONS.contains(file.extension.lowercase())) {
                    videoFiles.add(file)
                }
            }

            // If still empty, generate beautiful procedural sample MP4s into fallbackDir & targetDir
            if (videoFiles.isEmpty()) {
                val generated = SampleVideoGenerator.generateSampleVideosIfEmpty(fallbackDir)
                videoFiles.addAll(generated)

                // Also try generating into targetDir if possible
                try {
                    SampleVideoGenerator.generateSampleVideosIfEmpty(targetDir)
                } catch (e: Exception) {
                    // Ignore if targetDir permission not granted yet
                }
            }
        }

        // Map files to VideoItem
        val items = videoFiles.mapIndexed { index, file ->
            createVideoItemFromFile(file, index)
        }

        // Apply offline FYP Shuffle Algorithm
        shuffleFyp(items)
    }

    /**
     * Offline FYP Shuffle Algorithm:
     * Randomizes video order with Fisher-Yates shuffle to create a fresh algorithmic feed.
     */
    fun shuffleFyp(videos: List<VideoItem>): List<VideoItem> {
        val shuffled = videos.toMutableList()
        val random = Random()
        for (i in shuffled.size - 1 downTo 1) {
            val j = random.nextInt(i + 1)
            val temp = shuffled[i]
            shuffled[i] = shuffled[j]
            shuffled[j] = temp
        }
        return shuffled
    }

    /**
     * Load videos from user-picked SAF URIs (e.g. from gallery or file picker)
     */
    suspend fun loadFromUris(uris: List<Uri>): List<VideoItem> = withContext(Dispatchers.IO) {
        val items = uris.mapIndexed { index, uri ->
            val id = "saf_${uri.hashCode()}_$index"
            val fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "Video_$index.mp4"
            val savedSound = getSavedSoundTitle(id) ?: getSavedSoundTitle(fileName)
            val savedCaption = getSavedCaption(id) ?: getSavedCaption(fileName)
            val savedAuthor = getSavedAuthor(id) ?: getSavedAuthor(fileName)
            val isBookmarkedSaved = isVideoBookmarked(id) || isVideoBookmarked(fileName)

            VideoItem(
                id = id,
                uri = uri,
                filePath = uri.toString(),
                fileName = fileName,
                title = fileName.substringBeforeLast('.').replace('_', ' ').replace('-', ' '),
                authorName = (savedAuthor ?: "Offline Creator").removePrefix("@"),
                authorHandle = savedAuthor ?: "@creator_${index + 1}",
                caption = savedCaption ?: "Imported offline video #fyp #offline #localvideo",
                soundTitle = savedSound ?: "Original Sound - $fileName",
                durationMs = 15000L,
                sizeBytes = 5_000_000L,
                isLiked = likedVideoIds.contains(id),
                likeCount = 120 + (index * 37) % 500,
                isBookmarked = isBookmarkedSaved,
                bookmarkCount = if (isBookmarkedSaved) 46 else 45,
                commentCount = 14 + (index * 7) % 80,
                shareCount = 5 + (index * 3) % 20,
                isLooping = true,
                comments = getInitialCommentsFor(id)
            )
        }
        shuffleFyp(items)
    }

    private fun createVideoItemFromFile(file: File, index: Int): VideoItem {
        val id = file.absolutePath.hashCode().toString()
        val cleanName = file.nameWithoutExtension.replace('_', ' ').replace('-', ' ')
        var durationMs = 0L

        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(file.absolutePath)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationMs = durationStr?.toLongOrNull() ?: 0L
            retriever.release()
        } catch (e: Exception) {
            // In case codec reading fails
        }

        val handles = listOf("@yogreks", "@offline_star", "@clip_vault", "@soundwave", "@traveler")
        val handle = handles[index % handles.size]
        val authorName = handle.removePrefix("@")

        val hashtags = listOf(
            "Tanya jawab 😭 #fyp #lol #prank #harmlessprank #momoyomilkteabattle",
            "#offline #tiktok #fyp #trending",
            "#localvideo #aesthetic #vibes #loop",
            "#cinematic #chill #music #shorts"
        )
        val caption = if (index == 0) hashtags[0] else "$cleanName ${hashtags[index % hashtags.size]}"

        val sounds = listOf(
            "Original Audio - yogreks",
            "Trending Beat - $authorName",
            "Lofi Sunset Loop (Offline Edit)",
            "Midnight Synth - Ambient Mix"
        )

        val likeCount = if (index == 0) 13800 else 284 + (index * 142) % 4300
        val commentCount = if (index == 0) 141 else 28 + (index * 9) % 320
        val bookmarkCount = if (index == 0) 261 else 92 + (index * 29) % 850
        val shareCount = if (index == 0) 658 else 12 + (index * 4) % 80

        val savedSound = getSavedSoundTitle(id) ?: getSavedSoundTitle(file.name)
        val savedCaption = getSavedCaption(id) ?: getSavedCaption(file.name)
        val savedAuthor = getSavedAuthor(id) ?: getSavedAuthor(file.name)
        val isBookmarkedSaved = isVideoBookmarked(id) || isVideoBookmarked(file.name)

        return VideoItem(
            id = id,
            uri = file.toUri(),
            filePath = file.absolutePath,
            fileName = file.name,
            title = cleanName,
            authorName = (savedAuthor ?: authorName).removePrefix("@"),
            authorHandle = savedAuthor ?: handle,
            caption = savedCaption ?: caption,
            soundTitle = savedSound ?: sounds[index % sounds.size],
            durationMs = durationMs,
            sizeBytes = file.length(),
            isLiked = likedVideoIds.contains(id),
            likeCount = likeCount,
            isBookmarked = isBookmarkedSaved,
            bookmarkCount = if (isBookmarkedSaved) bookmarkCount + 1 else bookmarkCount,
            commentCount = commentCount,
            shareCount = shareCount,
            isLooping = true,
            isSample = file.name.startsWith("sample_") || file.name.contains("neon_") || file.name.contains("sunset_") || file.name.contains("kuis_"),
            comments = getInitialCommentsFor(id)
        )
    }

    fun toggleLike(videoId: String, isCurrentlyLiked: Boolean): Boolean {
        return if (isCurrentlyLiked) {
            likedVideoIds.remove(videoId)
            false
        } else {
            likedVideoIds.add(videoId)
            true
        }
    }

    fun getInitialCommentsFor(videoId: String): List<CommentItem> {
        val existing = localComments[videoId]
        if (existing != null) return existing

        val defaults = mutableListOf(
            CommentItem(
                id = "${videoId}_c1",
                username = "music_lover99",
                avatarColor = 0xFF25F4EE,
                text = "The audio quality on this offline clip is so crisp! 🔥",
                timestamp = "2h ago",
                likesCount = 42
            ),
            CommentItem(
                id = "${videoId}_c2",
                username = "offline_explorer",
                avatarColor = 0xFFFE2C55,
                text = "Smooth swipe transitions work flawlessly without Wi-Fi 📱✨",
                timestamp = "4h ago",
                likesCount = 18
            ),
            CommentItem(
                id = "${videoId}_c3",
                username = "dan_creator",
                avatarColor = 0xFFFFD700,
                text = "Love that it scans directly from Download/TikTokOffline folder!",
                timestamp = "1d ago",
                likesCount = 9
            )
        )
        localComments[videoId] = defaults
        return defaults
    }

    fun addComment(videoId: String, text: String): List<CommentItem> {
        val comments = localComments.getOrPut(videoId) { mutableListOf() }
        val newComment = CommentItem(
            id = "c_${System.currentTimeMillis()}",
            username = "You (Offline)",
            avatarColor = 0xFFFE2C55,
            text = text,
            timestamp = "Just now",
            likesCount = 0
        )
        comments.add(0, newComment)
        return comments.toList()
    }
}
