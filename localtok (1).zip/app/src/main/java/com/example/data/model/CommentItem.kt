package com.example.data.model

data class CommentItem(
    val id: String,
    val username: String,
    val avatarColor: Long,
    val text: String,
    val timestamp: String,
    val likesCount: Int = 0,
    val isLiked: Boolean = false
)
