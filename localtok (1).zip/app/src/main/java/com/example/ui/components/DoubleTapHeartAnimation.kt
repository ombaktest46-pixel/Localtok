package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.ui.theme.TikTokRed
import com.example.ui.viewmodel.FlyingHeart
import kotlin.math.roundToInt

@Composable
fun FlyingHeartItem(
    heart: FlyingHeart,
    onAnimationEnd: (Long) -> Unit
) {
    val scale = remember { Animatable(0.2f) }
    val alpha = remember { Animatable(1.0f) }
    val yOffset = remember { Animatable(0f) }

    LaunchedEffect(heart.id) {
        // Pop and scale in
        scale.animateTo(
            targetValue = 1.3f,
            animationSpec = tween(180, easing = FastOutSlowInEasing)
        )
        scale.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(100)
        )

        // Float up and fade out
        yOffset.animateTo(
            targetValue = -120f,
            animationSpec = tween(500, easing = FastOutSlowInEasing)
        )
        alpha.animateTo(
            targetValue = 0f,
            animationSpec = tween(250)
        )

        onAnimationEnd(heart.id)
    }

    Box(
        modifier = Modifier
            .offset {
                IntOffset(
                    x = (heart.x - 45).roundToInt(),
                    y = (heart.y - 45 + yOffset.value).roundToInt()
                )
            }
            .scale(scale.value)
            .alpha(alpha.value)
            .rotate(heart.rotation)
    ) {
        Icon(
            imageVector = Icons.Default.Favorite,
            contentDescription = null,
            tint = TikTokRed,
            modifier = Modifier.size(90.dp)
        )
    }
}
